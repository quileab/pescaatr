<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Bienvenidos</title>
</head>
<style>
  body{
    font-family: Arial, Helvetica, sans-serif;
    padding:1rem;
  }
  table{
    width: 100%;
    border-collapse: collapse;
    border-radius: 0.5rem;
    overflow: hidden;
  }
  th{
    background-color: #0045a5;
    color: #ffffff;
  }
  td,th{
    padding:0.5rem;
  }
  tr:nth-child(even) {
    background-color: #c3dcfe;
  }
  tr:nth-child(odd) {
    background-color: #dfecff;
  }
  h3{
    margin-top:0.2rem;
  }
</style>
<body>
  <h1>Bienvenidos</h1>
  Los esperamos para disfrutar de la fiesta!!!
  <h3>Equipo: <?php echo e($team['name']); ?></h3>
  Embarcación: <?php echo e($team['boatName']); ?> # <?php echo e($team['plate']); ?><br>
  <h3>Participantes:</h3>
  <table>
    <thead><tr><th>Nombre</th><th>Teléfono</th><th>Email</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $team['players']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($player['fullname']); ?></td>
      <td><?php echo e($player['phone']); ?></td>
      <td><?php echo e($player['email']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  
</body>
</html><?php /**PATH D:\qbweb\pescaatr\resources\views/emails/welcome.blade.php ENDPATH**/ ?>