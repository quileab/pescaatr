    <div {{ $attributes->class(["badge"])}}>
        {{ $value }}
    </div>