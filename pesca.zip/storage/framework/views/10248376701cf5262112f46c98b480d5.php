<?php

use Livewire\Volt\Component;

new class extends Component {
    //
}; ?>

<div>
    Index
</div>
<?php /**PATH D:\qbweb\pescaatr\resources\views\livewire\home.blade.php ENDPATH**/ ?>