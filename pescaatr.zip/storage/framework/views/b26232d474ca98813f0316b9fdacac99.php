<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Bienvenido</title>
</head>
<style>
  body{
    font-family: Arial, Helvetica, sans-serif;
    margin:25px !important;
    color:#333;
  }
  h1{
    font-weight: 900;
  }
  td{
    padding:10px;
  }
</style>
<body>
  <h1>Bienvenido</h1>
  Peña / Equipo: <strong><?php echo e($team->name); ?></strong><br><br>
  <table>
    <thead>
      <tr>
        <th>Participante</th>
        <th>email</th>
        <th>teléfono</th>
      </tr>
    </thead>
    <tbody>
  <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($player->fullname); ?></td>
        <td><?php echo e($player->email); ?></td>
        <td><?php echo e($player->phone); ?></td>
      </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <br>
  Los esperamos en junio para disfrutar de la fiesta!!!<br>
  En el archivo adjunto encontrará las bases y condiciones para participar.
</body>
</html><?php /**PATH C:\qb\qbweb\pescaatr\resources\views/emails/welcome.blade.php ENDPATH**/ ?>