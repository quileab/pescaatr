        <div>
            <label class="flex items-center gap-3 cursor-pointer">

                <!--[if BLOCK]><![endif]--><?php if($right): ?>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(["flex-1" => !$tight]); ?>">
                        <?php echo e($label); ?>

                    </span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <input type="checkbox" <?php echo e($attributes->whereDoesntStartWith('class')); ?> <?php echo e($attributes->class(['toggle toggle-primary'])); ?>  />

                <!--[if BLOCK]><![endif]--><?php if(!$right): ?>
                    <?php echo e($label); ?>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </label>

            <!-- HINT -->
            <!--[if BLOCK]><![endif]--><?php if($hint): ?>
                <div class="label-text-alt text-gray-400 py-1 pb-0"><?php echo e($hint); ?></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div><?php /**PATH C:\qb\qbweb\pescaatr\storage\framework\views/002e3464ad10c51ae28546c014490eee.blade.php ENDPATH**/ ?>