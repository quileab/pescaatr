    <div x-data="{
                    selection: @entangle($attributes->wire('model')),
                    colspanSize: 0,
                    toggleSelection(checked){
                        checked ? this.selection = @js($getAllIds()) : this.selection = []
                    },
                    toggleExpand(key){
                         this.selection.includes(key)
                            ? this.selection = this.selection.filter(i => i !== key)
                            : this.selection.push(key)
                    },
                    isExpanded(key){
                        return this.selection.includes(key)
                    },
                    init() {
                        this.colspanSize = $refs.headers.childElementCount
                    }
                 }"
                    class="overflow-x-auto"
    >
        <table
            {{
                $attributes
                    ->except('wire:model')
                    ->class([
                        'table',
                        'table-zebra' => $striped,
                        'cursor-pointer' => $attributes->hasAny(['@row-click', 'link'])
                    ])
            }}
        >
            <!-- HEADERS -->
            <thead @class(["text-black dark:text-gray-200", "hidden" => $noHeaders])>
                <tr x-ref="headers">
                    <!-- CHECKBOX -->
                    @if($selectable)
                        <th class="w-1">
                            <input
                                type="checkbox"
                                class="checkbox checkbox-sm"
                                x-ref="mainCheckbox"
                                @click="toggleSelection($el.checked)" />
                        </th>
                    @endif

                    <!-- EXPAND EXTRA HEADER -->
                    @if($expandable)
                        <th class="w-1"></th>
                     @endif

                    @foreach($headers as $header)
                         @php
                            # Scoped slot`s name like `user.city` are compiled to `user___city` through `@scope / @endscope`.
                            # So we use current `$header` key  to find that slot on context.
                            $temp_key = str_replace('.', '___', $header['key'])
                        @endphp

                        <th
                            class="@if($isSortable($header)) cursor-pointer hover:bg-base-200 @endif {{ $header['class'] ?? ' ' }}"

                            @if($sortBy && $isSortable($header))
                                @click="$wire.set('sortBy', {column: '{{ $getSort($header)['column'] }}', direction: '{{ $getSort($header)['direction'] }}' })"
                            @endif
                        >
                            {{ isset(${"header_".$temp_key}) ? ${"header_".$temp_key}($header) : $header['label'] }}

                            @if($isSortable($header) && $isSortedBy($header))
                                <x-mary-icon :name="$getSort($header)['direction'] == 'asc' ? 'o-arrow-small-down' : 'o-arrow-small-up'"  class="w-4 h-4 mb-1" />
                            @endif
                        </th>
                    @endforeach

                    <!-- ACTIONS (Just a empty column) -->
                    @if($actions)
                        <th class="w-1"></th>
                    @endif
                </tr>
            </thead>

            <!-- ROWS -->
            <tbody>
                @foreach($rows as $k => $row)
                    @php
                        # helper variable to provide the loop context
                        $this->loop = $loop;
                    @endphp

                    <tr wire:key="{{ $uuid }}-{{ $k }}" class="hover:bg-base-200/50 {{ $rowClasses($row) }}" @click="$dispatch('row-click', {{ json_encode($row) }});">
                        <!-- CHECKBOX -->
                        @if($selectable)
                            <td class="w-1">
                                <input
                                    type="checkbox"
                                    class="checkbox checkbox-sm checkbox-primary"
                                    value="{{ data_get($row, $selectableKey) }}"
                                    x-model="selection"
                                    @click="$dispatch('row-selection', { row: {{ json_encode($row) }}, selected: $el.checked }); $refs.mainCheckbox.checked = false" />
                            </td>
                        @endif

                        <!-- EXPAND ICON -->
                        @if($expandable)
                            <td class="w-1 pr-0">
                                <x-mary-icon
                                    name="o-chevron-down"
                                    ::class="isExpanded({{ data_get($row, $expandableKey) }}) || '-rotate-90 !text-current !bg-base-200'"
                                    class="cursor-pointer p-2 w-8 h-8 bg-base-300 rounded-lg"
                                    @click="toggleExpand({{ data_get($row, $expandableKey) }});" />
                            </td>
                         @endif

                        <!--  ROW VALUES -->
                        @foreach($headers as $header)
                            @php
                                # Scoped slot`s name like `user.city` are compiled to `user___city` through `@scope / @endscope`.
                                # So we use current `$header` key  to find that slot on context.
                                $temp_key = str_replace('.', '___', $header['key'])
                            @endphp

                            <!--  HAS CUSTOM SLOT ? -->
                            @if(isset(${"cell_".$temp_key}))
                                <td @class([$cellClasses($row, $header), "p-0" => $link])>
                                    @if($link)
                                        <a href="{{ $redirectLink($row) }}" wire:navigate class="block py-3 px-4">
                                    @endif

                                    {{ ${"cell_".$temp_key}($row)  }}

                                    @if($link)
                                        </a>
                                     @endif
                                </td>
                            @else
                                <td @class([$cellClasses($row, $header), "p-0" => $link])>
                                    @if($link)
                                        <a href="{{ $redirectLink($row) }}" wire:navigate class="block py-3 px-4">
                                    @endif

                                    {{ data_get($row, $header['key']) }}

                                    @if($link)
                                        </a>
                                    @endif
                                </td>
                            @endif
                        @endforeach

                        <!-- ACTIONS -->
                        @if($actions)
                            <td class="text-right py-0" @click="event.stopPropagation()">{{ $actions($row) }}</td>
                        @endif
                    </tr>

                    <!-- EXPANSION SLOT -->
                    @if($expandable)
                        <tr wire:key="{{ $uuid }}-{{ $k }}--expand" :class="isExpanded({{ data_get($row, $expandableKey) }}) || 'hidden'">
                            <td :colspan="colspanSize">
                                {{ $expansion($row) }}
                            </td>
                        </tr>
                    @endif
                @endforeach
            </tbody>
        </table>

        <!-- Pagination -->
        @if($withPagination)
            <div class="mary-table-pagination">
                <div class="border border-x-0 border-t-0 border-b-1 border-b-base-300 mb-5"></div>

                {{ $rows->onEachSide(1)->links(data: ['scrollTo' => false])  }}
            </div>
        @endif
    </div>