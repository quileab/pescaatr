<?php

use Livewire\Volt\Component;

new class extends Component {
    //
}; ?>

<div>
    Users.Create
</div>
<?php /**PATH C:\qb\qbweb\pescaatr\resources\views\livewire\users\create.blade.php ENDPATH**/ ?>