<?php

use Livewire\Volt\Component;

new class extends Component {
    //
}; ?>

<div>
    //
</div>
<?php /**PATH C:\qb\qbweb\pescaatr\resources\views\livewire\paymentslist.blade.php ENDPATH**/ ?>