    <div x-data="{
                    selection: <?php if ((object) ($attributes->wire('model')) instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($attributes->wire('model')->value()); ?>')<?php echo e($attributes->wire('model')->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e($attributes->wire('model')); ?>')<?php endif; ?>,
                    colspanSize: 0,
                    toggleSelection(checked){
                        checked ? this.selection = <?php echo \Illuminate\Support\Js::from($getAllIds())->toHtml() ?> : this.selection = []
                    },
                    toggleExpand(key){
                         this.selection.includes(key)
                            ? this.selection = this.selection.filter(i => i !== key)
                            : this.selection.push(key)
                    },
                    isExpanded(key){
                        return this.selection.includes(key)
                    },
                    init() {
                        this.colspanSize = $refs.headers.childElementCount
                    }
                 }"
                    class="overflow-x-auto"
    >
        <table
            <?php echo e($attributes
                    ->except('wire:model')
                    ->class([
                        'table',
                        'table-zebra' => $striped,
                        'cursor-pointer' => $attributes->hasAny(['@row-click', 'link'])
                    ])); ?>

        >
            <!-- HEADERS -->
            <thead class="<?php echo \Illuminate\Support\Arr::toCssClasses(["text-black dark:text-gray-200", "hidden" => $noHeaders]); ?>">
                <tr x-ref="headers">
                    <!-- CHECKBOX -->
                    <!--[if BLOCK]><![endif]--><?php if($selectable): ?>
                        <th class="w-1">
                            <input
                                type="checkbox"
                                class="checkbox checkbox-sm"
                                x-ref="mainCheckbox"
                                @click="toggleSelection($el.checked)" />
                        </th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- EXPAND EXTRA HEADER -->
                    <!--[if BLOCK]><![endif]--><?php if($expandable): ?>
                        <th class="w-1"></th>
                     <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php
                            # Scoped slot`s name like `user.city` are compiled to `user___city` through `@scope / @endscope`.
                            # So we use current `$header` key  to find that slot on context.
                            $temp_key = str_replace('.', '___', $header['key'])
                        ?>

                        <th
                            class="<?php if($isSortable($header)): ?> cursor-pointer hover:bg-base-200 <?php endif; ?> <?php echo e($header['class'] ?? ' '); ?>"

                            <?php if($sortBy && $isSortable($header)): ?>
                                @click="$wire.set('sortBy', {column: '<?php echo e($getSort($header)['column']); ?>', direction: '<?php echo e($getSort($header)['direction']); ?>' })"
                            <?php endif; ?>
                        >
                            <?php echo e(isset(${"header_".$temp_key}) ? ${"header_".$temp_key}($header) : $header['label']); ?>


                            <?php if($isSortable($header) && $isSortedBy($header)): ?>
                                <?php if (isset($component)) { $__componentOriginalce0070e6ae017cca68172d0230e44821 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce0070e6ae017cca68172d0230e44821 = $attributes; } ?>
<?php $component = Mary\View\Components\Icon::resolve(['name' => $getSort($header)['direction'] == 'asc' ? 'o-arrow-small-down' : 'o-arrow-small-up'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mary-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Mary\View\Components\Icon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4 mb-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce0070e6ae017cca68172d0230e44821)): ?>
<?php $attributes = $__attributesOriginalce0070e6ae017cca68172d0230e44821; ?>
<?php unset($__attributesOriginalce0070e6ae017cca68172d0230e44821); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce0070e6ae017cca68172d0230e44821)): ?>
<?php $component = $__componentOriginalce0070e6ae017cca68172d0230e44821; ?>
<?php unset($__componentOriginalce0070e6ae017cca68172d0230e44821); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- ACTIONS (Just a empty column) -->
                    <!--[if BLOCK]><![endif]--><?php if($actions): ?>
                        <th class="w-1"></th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tr>
            </thead>

            <!-- ROWS -->
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        # helper variable to provide the loop context
                        $this->loop = $loop;
                    ?>

                    <tr wire:key="<?php echo e($uuid); ?>-<?php echo e($k); ?>" class="hover:bg-base-200/50 <?php echo e($rowClasses($row)); ?>" @click="$dispatch('row-click', <?php echo e(json_encode($row)); ?>);">
                        <!-- CHECKBOX -->
                        <!--[if BLOCK]><![endif]--><?php if($selectable): ?>
                            <td class="w-1">
                                <input
                                    type="checkbox"
                                    class="checkbox checkbox-sm checkbox-primary"
                                    value="<?php echo e(data_get($row, $selectableKey)); ?>"
                                    x-model="selection"
                                    @click="$dispatch('row-selection', { row: <?php echo e(json_encode($row)); ?>, selected: $el.checked }); $refs.mainCheckbox.checked = false" />
                            </td>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- EXPAND ICON -->
                        <!--[if BLOCK]><![endif]--><?php if($expandable): ?>
                            <td class="w-1 pr-0">
                                <?php if (isset($component)) { $__componentOriginalce0070e6ae017cca68172d0230e44821 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce0070e6ae017cca68172d0230e44821 = $attributes; } ?>
<?php $component = Mary\View\Components\Icon::resolve(['name' => 'o-chevron-down'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mary-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Mary\View\Components\Icon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([':class' => 'isExpanded('.e(data_get($row, $expandableKey)).') || \'-rotate-90 !text-current !bg-base-200\'','class' => 'cursor-pointer p-2 w-8 h-8 bg-base-300 rounded-lg','@click' => 'toggleExpand('.e(data_get($row, $expandableKey)).');']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce0070e6ae017cca68172d0230e44821)): ?>
<?php $attributes = $__attributesOriginalce0070e6ae017cca68172d0230e44821; ?>
<?php unset($__attributesOriginalce0070e6ae017cca68172d0230e44821); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce0070e6ae017cca68172d0230e44821)): ?>
<?php $component = $__componentOriginalce0070e6ae017cca68172d0230e44821; ?>
<?php unset($__componentOriginalce0070e6ae017cca68172d0230e44821); ?>
<?php endif; ?>
                            </td>
                         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--  ROW VALUES -->
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                # Scoped slot`s name like `user.city` are compiled to `user___city` through `@scope / @endscope`.
                                # So we use current `$header` key  to find that slot on context.
                                $temp_key = str_replace('.', '___', $header['key'])
                            ?>

                            <!--  HAS CUSTOM SLOT ? -->
                            <!--[if BLOCK]><![endif]--><?php if(isset(${"cell_".$temp_key})): ?>
                                <td class="<?php echo \Illuminate\Support\Arr::toCssClasses([$cellClasses($row, $header), "p-0" => $link]); ?>">
                                    <!--[if BLOCK]><![endif]--><?php if($link): ?>
                                        <a href="<?php echo e($redirectLink($row)); ?>" wire:navigate class="block py-3 px-4">
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <?php echo e(${"cell_".$temp_key}($row)); ?>


                                    <!--[if BLOCK]><![endif]--><?php if($link): ?>
                                        </a>
                                     <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            <?php else: ?>
                                <td class="<?php echo \Illuminate\Support\Arr::toCssClasses([$cellClasses($row, $header), "p-0" => $link]); ?>">
                                    <!--[if BLOCK]><![endif]--><?php if($link): ?>
                                        <a href="<?php echo e($redirectLink($row)); ?>" wire:navigate class="block py-3 px-4">
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    <?php echo e(data_get($row, $header['key'])); ?>


                                    <!--[if BLOCK]><![endif]--><?php if($link): ?>
                                        </a>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- ACTIONS -->
                        <!--[if BLOCK]><![endif]--><?php if($actions): ?>
                            <td class="text-right py-0" @click="event.stopPropagation()"><?php echo e($actions($row)); ?></td>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>

                    <!-- EXPANSION SLOT -->
                    <!--[if BLOCK]><![endif]--><?php if($expandable): ?>
                        <tr wire:key="<?php echo e($uuid); ?>-<?php echo e($k); ?>--expand" :class="isExpanded(<?php echo e(data_get($row, $expandableKey)); ?>) || 'hidden'">
                            <td :colspan="colspanSize">
                                <?php echo e($expansion($row)); ?>

                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        <!-- Pagination -->
        <!--[if BLOCK]><![endif]--><?php if($withPagination): ?>
            <div class="mary-table-pagination">
                <div class="border border-x-0 border-t-0 border-b-1 border-b-base-300 mb-5"></div>

                <?php echo e($rows->onEachSide(1)->links(data: ['scrollTo' => false])); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div><?php /**PATH C:\qb\qbweb\pescaatr\storage\framework\views/8eed5b7adf7dce6b2f8c7affa853ffa7.blade.php ENDPATH**/ ?>